<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'diamanopay' => [
        'base_url' => env('DIAMANOPAY_BASE_URL', 'https://api.diamanopay.com'),
        'access_token' => env('DIAMANOPAY_ACCESS_TOKEN'),
        'provider' => env('PAYMENT_PROVIDER', 'WAVE'),
        'webhook_url' => env('DIAMANOPAY_WEBHOOK_URL'),
        'client_id' => env('DIAMANOPAY_CLIENT_ID'),
        'client_secret' => env('DIAMANOPAY_CLIENT_SECRET'),
        'webhook_secret' => env('DIAMANOPAY_WEBHOOK_SECRET'),
    ],

    'openrouteservice' => [
        'api_key' => env('OPENROUTESERVICE_API_KEY'),
        'base_url' => env('OPENROUTESERVICE_BASE_URL', 'https://api.openrouteservice.org'),
    ],

    'anthropic' => [
        'url' => env('ANTHROPIC_API_URL', 'https://api.anthropic.com/v1/messages'),
        'key' => env('ANTHROPIC_API_KEY'),
        'model' => env('ANTHROPIC_MODEL', 'claude-sonnet-4-5'),
    ],

];
