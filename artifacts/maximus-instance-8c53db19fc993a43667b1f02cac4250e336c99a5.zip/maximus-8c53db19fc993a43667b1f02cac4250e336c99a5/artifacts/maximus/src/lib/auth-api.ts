import { requestJson } from './api-request';

export type AuthUser = {
  role: 'maximus_admin' | 'company_admin' | 'sector_manager' | 'employee';
  displayName: string;
  companyId?: string;
  employeeId?: string;
  sectorIds: string[];
  permissions?: Record<string, string[]>;
};

export type PublicCompanyLogin = {
  name: string;
  slug: string;
  profilePhoto?: string | null;
  primaryColor: string;
  accentColor: string;
  sidebarColor: string;
};

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  return requestJson<T>(path, options, { fallbackMessage: 'La connexion MAXIMUS a échoué.' });
}

export const authApi = {
  login: (email: string, password: string) => request<{ user: AuthUser }>('/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  }),
  companyLoginInfo: (slug: string) =>
    request<{ company: PublicCompanyLogin }>(`/auth/company-login/${encodeURIComponent(slug)}`),
  companyLogin: (slug: string, email: string, password: string) =>
    request<{ user: AuthUser }>(`/auth/company-login/${encodeURIComponent(slug)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    }),
  session: () => request<{ user: AuthUser | null }>('/auth/session'),
  logout: () => request<void>('/auth/logout', { method: 'POST' }),
  provisionAccount: (input: {
    id: string;
    email: string;
    displayName: string;
    phone?: string;
    companyId: string;
    employeeId: string;
    sectorIds: string[];
    role: 'sector_manager' | 'employee';
    permissions?: Record<string, string[]>;
    password?: string;
  }) => request<{ ok: true }>('/auth/accounts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  }),
  provisionCompanyAdmin: (input: {
    id: string;
    email: string;
    displayName: string;
    companyId: string;
    password: string;
  }) => request<{ ok: true }>('/auth/company-admins', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  }),
  updateCompanyPassword: (companyId: string, password: string) => request<{ ok: true }>('/auth/company-password', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ companyId, password }),
  }),
  revokeAccount: (employeeId: string) => request<void>(`/auth/accounts/${encodeURIComponent(employeeId)}`, { method: 'DELETE' }),
};